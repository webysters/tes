package net.runelite.client.plugins.customclientresizing;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;

@ConfigGroup(CustomClientResizingPlugin.CONFIG_GROUP)
public interface CustomClientResizingConfig extends Config
{
}
